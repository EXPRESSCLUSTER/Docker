#!/bin/bash
set -o pipefail

PRDNAME="clusterpro"
INSTALL_PATH=/opt/nec/clusterpro
CONFIG_TEMPLATE_NAME=sss4mariadb.conf
CONFIG_PATH=${INSTALL_PATH}/etc/clp.conf
SCRIPT_PATH=${INSTALL_PATH}/etc/systemd
SCRIPT_START_ORDER="${PRDNAME}_evt.sh ${PRDNAME}_trn.sh ${PRDNAME}.sh ${PRDNAME}_webmgr.sh ${PRDNAME}_alertsync.sh"
SCRIPT_STOP_ORDER="${PRDNAME}_alertsync.sh ${PRDNAME}_webmgr.sh ${PRDNAME}_trn.sh ${PRDNAME}_evt.sh"
CL_STOP_TIMEOUT_SEC=30

function trace() {
	local type="$1"; shift
	printf '%s [%s] [%s]: %s\n' "$(date --rfc-3339=seconds)" "$type" "$(basename $0)" "$*"
}
function trace_info() {
	trace info "$@"
}
function trace_warn() {
	trace warn "$@" >&2
}
function trace_error() {
	trace erro "$@" >&2
	exit 1
}

function export_default_environment_variables() {
	trace_info "start to export default environment variables."

	# if these are undefined, set default value.
	: ${SSS_MAIN_CONTAINER_PROCNAME:=mysqld}
	: ${SSS_MAIN_CONTAINER_INIT_CMD:=docker-entrypoint.sh}
	: ${SSS_RECOVER_SIGNAL_TYPE:=TERM}
	: ${SSS_RECOVER_SIGNAL_TIMEOUT_SEC:=10}
	: ${SSS_CONFIG_MOUNTPOINT:=/config}
	: ${SSS_LICENSE_MOUNTPOINT:=/license}
	export SSS_MAIN_CONTAINER_PROCNAME
	export SSS_MAIN_CONTAINER_INIT_CMD
	export SSS_RECOVER_SIGNAL_TYPE
	export SSS_RECOVER_SIGNAL_TIMEOUT_SEC
	export SSS_CONFIG_MOUNTPOINT
	export SSS_LICENSE_MOUNTPOINT

	trace_info "show exported environment variables as follows."
	printenv
}

function replace_placeholders_on_config() {
	trace_info "start to replace config file."

	local infile=${SSS_CONFIG_MOUNTPOINT}/${CONFIG_TEMPLATE_NAME}
	local outfile=${CONFIG_PATH}
	if [ ! -f ${infile} ]; then
		trace_error "failed to replace config file.(config is not mounted)"
	fi

	# set default parameters if environment variables are undefined.
	: ${SSS_MONITOR_DB_NAME:=watch}
	: ${SSS_MONITOR_DB_USER:=root}
	: ${SSS_MONITOR_DB_PASS:=password}
	: ${SSS_MONITOR_DB_IPADDR:=127.0.0.1}
	: ${SSS_MONITOR_DB_PORT:=3306}
	: ${SSS_MONITOR_DB_METHOD:=0}
	: ${SSS_MONITOR_DB_ENGINE:=InnoDB} # InnoDB|MyISAM
	: ${SSS_MONITOR_DB_LIBPATH:=/usr/lib/x86_64-linux-gnu/libmysqlclient.so.20}
	: ${SSS_MONITOR_PERIOD_SEC:=10}
	: ${SSS_MONITOR_TIMEOUT_SEC:=10}
	: ${SSS_MONITOR_RETRY_CNT:=2}
	: ${SSS_MONITOR_INITIAL_DELAY_SEC:=0}
	: ${SSS_RECOVERY_CNT:=3}
	: ${SSS_NORECOVERY:=0} # 0|1

	# replace the placeholder on template config file with environment variables.
	sed \
		-e "s;__SSS_MONITOR_DB_NAME__;${SSS_MONITOR_DB_NAME};g" \
		-e "s;__SSS_MONITOR_DB_USER__;${SSS_MONITOR_DB_USER};g" \
		-e "s;__SSS_MONITOR_DB_PASS__;${SSS_MONITOR_DB_PASS};g" \
		-e "s;__SSS_MONITOR_DB_IPADDR__;${SSS_MONITOR_DB_IPADDR};g" \
		-e "s;__SSS_MONITOR_DB_PORT__;${SSS_MONITOR_DB_PORT};g" \
		-e "s;__SSS_MONITOR_DB_METHOD__;${SSS_MONITOR_DB_METHOD};g" \
		-e "s;__SSS_MONITOR_DB_ENGINE__;${SSS_MONITOR_DB_ENGINE};g" \
		-e "s;__SSS_MONITOR_DB_LIBPATH__;${SSS_MONITOR_DB_LIBPATH};g" \
		-e "s;__SSS_MONITOR_PERIOD_SEC__;${SSS_MONITOR_PERIOD_SEC};g" \
		-e "s;__SSS_MONITOR_TIMEOUT_SEC__;${SSS_MONITOR_TIMEOUT_SEC};g" \
		-e "s;__SSS_MONITOR_RETRY_CNT__;${SSS_MONITOR_RETRY_CNT};g" \
		-e "s;__SSS_MONITOR_INITIAL_DELAY_SEC__;${SSS_MONITOR_INITIAL_DELAY_SEC};g" \
		-e "s;__SSS_RECOVERY_CNT__;${SSS_RECOVERY_CNT};g" \
		-e "s;__SSS_NORECOVERY__;${SSS_NORECOVERY};g" \
		< ${infile} > ${outfile}; local ret=$?

	if [ $ret -ne 0 ]; then
		trace_error "failed to replace config file.($ret)"
	else
		trace_info  "suceeded to replace config file."
	fi
}

function register_license () {
	trace_info "start to register license file."

	if [ ! -d ${SSS_LICENSE_MOUNTPOINT} ]; then
		trace_info "failed to register license file.(license is not mounted)"
	else
		# register license files
		clplcnsc -i ${SSS_LICENSE_MOUNTPOINT}/*; local ret=$?
		if [ $ret -ne 0 ]; then
			trace_warn "failed to register license file.($ret)"
		fi
	fi

	# check if any valid license is registered.
	if clplcnsc -l | grep Status | awk '{print $2}' | grep valid > /dev/null; then
		trace_info "succeeded to register license file."
	else
		trace_error "failed to register license file."
	fi
}

function start_service() {
	trace_info "start services."

	# start up services.
	for cmd in ${SCRIPT_START_ORDER}; do
		${SCRIPT_PATH}/${cmd} start; local ret=$?
		if [ $ret -ne 0 ]; then
			trace_error "${cmd} start failed.($ret)"
		else
			trace_info "${cmd} start succeeded."
		fi
	done
}

function wait_service_ready() {
	trace_info "wait for the service to be ready."

	while :; do
		if [ "X$(clpstat --long | grep "*$(hostname)" | awk '{print $3}')" = "XOnline" ]; then
			trace_info "the service is ready!!"
			break
		fi
		sleep 1
	done
}

function stop_service() {
	trace_info "stop services."

	clpcl -t -w ${CL_STOP_TIMEOUT_SEC}
	# stop services.
	for cmd in ${SCRIPT_STOP_ORDER}; do
		${SCRIPT_PATH}/${cmd} stop; local ret=$?
		if [ $ret -ne 0 ]; then
			trace_warn "${cmd} stop failed.($ret)"
		else
			trace_info "${cmd} stop succeeded."
		fi
	done
}

function cleanup() {
	trace_warn "the signal is caught."

	stop_service
	exit 0
}

export_default_environment_variables
replace_placeholders_on_config
register_license
start_service
wait_service_ready

# register TERM handler to shutdown gracefully.
# - e.g. Pod deleted, Pod restarted.
trap cleanup TERM

# wait for SIGTERM signal.
while :; do
	sleep 1
done
exit 0
