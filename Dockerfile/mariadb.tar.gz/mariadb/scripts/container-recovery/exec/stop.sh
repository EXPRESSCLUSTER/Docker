#! /bin/bash
#***************************************
#*               stop.sh               *
#***************************************

#ulimit -s unlimited

function trace() {
	local type="$1"; shift
	printf '%s [%s] [%s]: %s\n' "$(date --rfc-3339=seconds)" "$type" "$(basename $0)" "$*"
}
function trace_info() {
	trace info "$@"
}
function trace_warn() {
	trace warn "$@" >&2
}
function trace_error() {
	trace erro "$@" >&2
	exit 1
}

function kill_proc() {
	local signal=$1
	local timeout=$2
	local pids=$(pidof ${SSS_MAIN_CONTAINER_PROCNAME})
	if [ "${pids}" != "" ]; then
		trace_info "kill -${signal} ${SSS_MAIN_CONTAINER_PROCNAME}(${pids}). timeout is ${timeout} seconds."
		pkill -x ${SSS_MAIN_CONTAINER_PROCNAME} -${signal}
	else
		trace_warn "${SSS_MAIN_CONTAINER_PROCNAME} is not running."
	fi

	local elapsed=0
	for pid in ${pids}; do
		trace_info "check if ${SSS_MAIN_CONTAINER_PROCNAME}(${pid}) disappears."
		while [ ${elapsed} -lt ${timeout} ]; do
			if ! $(kill -0 ${pid} > /dev/null 2>&1); then
				trace_info "${SSS_MAIN_CONTAINER_PROCNAME}(${pid}) disappeared."
				break
			else
				trace_warn "${SSS_MAIN_CONTAINER_PROCNAME}(${pid}) does not disappear."
			fi
			sleep ${PERIOD}
			elapsed=$(expr ${elapsed} + ${PERIOD})
		done
	done

	if [ ${elapsed} -ge ${timeout} ]; then
		trace_warn "gave up ${signal}."
		return 1
	fi

	return 0
}

# stop the main container forcibely.
SIGNAL=("${SSS_RECOVER_SIGNAL_TYPE}" "KILL")
TIMEOUT=(${SSS_RECOVER_SIGNAL_TIMEOUT_SEC} 20)
PERIOD=1

trace_info "started."
if [ "${CLP_FACTOR}" != "RESOURCERESTART" -a "${CLP_FACTOR}" != "GROUPRESTART" ]; then
	# in case of no monitoring error, do nothing
	trace_info "CLP_FACTOR is ${CLP_FACTOR}, do nothing."
	exit 0
fi

kill_proc ${SIGNAL[0]} ${TIMEOUT[0]}; ret=$?
if [ ${ret} -ne 0 ]; then
	kill_proc ${SIGNAL[1]} ${TIMEOUT[1]}; ret=$?
	if [ ${ret} -ne 0 ]; then
		trace_error "timed out. exited."
	fi
fi

trace_info "successfully exited."
exit 0
