#! /bin/bash
#***************************************
#*              start.sh               *
#***************************************

#ulimit -s unlimited

function trace() {
	local type="$1"; shift
	printf '%s [%s] [%s]: %s\n' "$(date --rfc-3339=seconds)" "$type" "$(basename $0)" "$*"
}
function trace_info() {
	trace info "$@"
}
function trace_warn() {
	trace warn "$@" >&2
}
function trace_error() {
	trace erro "$@" >&2
	exit 1
}

# waiting for the main container to be up.
TIMEOUT=300
PERIOD=1
ELAPSED=0

trace_info "started."
trace_info "main process: ${SSS_MAIN_CONTAINER_PROCNAME}"
trace_info "init command: ${SSS_MAIN_CONTAINER_INIT_CMD}"
while [ ${ELAPSED} -lt ${TIMEOUT} ]; do
	MAIN_CONTAINER_PIDS=$(pidof ${SSS_MAIN_CONTAINER_PROCNAME})
	if [ "${MAIN_CONTAINER_PIDS}" != "" ] \
	&& ! ps aux | grep ${SSS_MAIN_CONTAINER_INIT_CMD} | grep -v grep > /dev/null; then
		trace_info "${SSS_MAIN_CONTAINER_PROCNAME}(${MAIN_CONTAINER_PIDS}) is up."
		break
	else
		trace_warn "${SSS_MAIN_CONTAINER_PROCNAME} is not up."
	fi
	sleep ${PERIOD}
	ELAPSED=$(expr ${ELAPSED} + ${PERIOD})
done

if [ ${ELAPSED} -ge ${TIMEOUT} ]; then
	trace_error "timed out. exited."
fi

trace_info "successfully exited."
exit 0
